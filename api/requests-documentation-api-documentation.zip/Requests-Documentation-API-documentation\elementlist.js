
var ApiGen = ApiGen || {};
ApiGen.elements = [["class","Requests"],["class","Requests_Auth"],["class","Requests_Auth_Basic"],["class","Requests_Exception"],["class","Requests_Hooks"],["class","Requests_IDNAEncoder"],["class","Requests_IPv6"],["class","Requests_IRI"],["class","Requests_Response"],["class","Requests_Response_Headers"],["class","Requests_Transport"],["class","Requests_Transport_cURL"],["class","Requests_Transport_fsockopen"]];
